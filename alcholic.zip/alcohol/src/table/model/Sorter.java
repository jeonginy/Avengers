package table.model;

import javax.swing.table.*;
import java.util.*;
import table.model.exception.SortException;

/**
 * Perform sorting of table's data.
 *
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class Sorter {

    /**
     * Original TableModel.
     */
    protected TableModel sourceModel;
    /**
     * Sort columns.
     */
    protected int[] sortColumnIndexes;
    /**
     * Sort orders for each column from sortColumnIndexes.
     */
    protected boolean[] sortOrders;

    /**
     * Contains indexes pairs which are used for quick sort.
     */
    protected ArrayList pairList=new ArrayList();
    /**
     * Current index pair.
     */
    protected int pairListPointer=-1;

    /**
     * Array of sorted row indexes.
     */
    protected int[] sortResult;

    /**
     * Creates new instance.
     */
    public Sorter() {
        this(null,null,null);
    }

    /**
     * Constructs sorter with specified TableModel.
     *
     * @param source original TableModel.
     */
    public Sorter(TableModel source) {
        this(source,null,null);
    }

    /**
     * Constructs sorter with specified TableModel and group indexes.
     *
     * @param source original TableModel.
     * @param sortColumnIndexes group indexes.
     * @param sortOrders sort orders (true ascending).
     */
    public Sorter(TableModel source, int[] sortColumnIndexes, boolean[] sortOrders) {
        this.sourceModel=source;
        this.sortColumnIndexes=sortColumnIndexes;
        this.sortOrders=sortOrders;
    }

    /**
     * Sets original TableModel.
     *
     * @param source original TableModel.
     */
    public void setSourceTableModel(TableModel source) {
        this.sourceModel=source;
    }

    /**
     * Sets sort regim.
     *
     * @param sortColumnIndexes indexes of sort columns.
     * @param sortOrders orders of sorting.
     * @throws SortException
     */
    public void setSort(int[] sortColumnIndexes,boolean[] sortOrders) throws SortException {
        if (sortColumnIndexes.length!=sortOrders.length) {
            throw new SortException("Number of sort column indexes isn't equal to number of sort orders!");
        }
        this.sortColumnIndexes=sortColumnIndexes;
        this.sortOrders=sortOrders;
    }

//------------------------------------------------------------------------------
   /**
    * Perform sorting,
    *
    * @return row indexes according to sort orders.
    */
    public int[] sort() {
        if ((sourceModel==null) || (sortColumnIndexes==null)) {
            return null;
        }
        int rowCount=sourceModel.getRowCount();
        sortResult=new int[rowCount];
        for (int i=0; i<rowCount; i++) {
            sortResult[i]=i;
        }
        addIndexPair(new IndexPair(0,rowCount-1));
        pairListPointer=0;
        while (pairListPointer<pairList.size()) {
            IndexPair currentPair=(IndexPair)pairList.get(pairListPointer);
            quickSort(currentPair.startIndex,currentPair.endIndex);
            pairListPointer++;

        }
        return sortResult;
    }

    /**
     * Adds index pair to sort. (It's used for quick sort implementation).
     * @param pair index pair.
     */
    protected void addIndexPair(IndexPair pair) {
        pairList.add(pair);
    }

    /**
     * Compares two table's row.
     *
     * @param startIndex index of the first row.
     * @param endIndex index of the second row.
     * @return -1 less, 0 equal, 1 more
     */
    protected int compare(int startIndex,int endIndex) {
        if (startIndex==endIndex)
            return 0;
        int sortCount=sortColumnIndexes.length;
        for (int i=0; i<sortCount; i++) {
            int sortColumnIndex=sortColumnIndexes[i];
            boolean isAscOrder=sortOrders[i];
            Class columnClass=sourceModel.getColumnClass(sortColumnIndex);
            boolean isComparable= (Comparable.class.isAssignableFrom(columnClass));
            //start row value
            Object startObj=sourceModel.getValueAt(sortResult[startIndex],sortColumnIndex);
            //end row
            Object endObj=sourceModel.getValueAt(sortResult[endIndex],sortColumnIndex);
            if (startObj==null) {
                if (startObj==endObj)
                    continue;
                else {
                    int res= -1;
                    if (!isAscOrder)
                        res*=-1;
                    return res;
                }
            }
            else if (endObj==null) {
                int res=1;
                if (!isAscOrder)
                    res*=-1;
                return res;
            }

            int compareResult=0;
            if (isComparable) {
                compareResult=((Comparable)startObj).compareTo(endObj);
            }
            else { //isn't comparable (uses toString method to sort content)
                compareResult=startObj.toString().compareTo(endObj.toString());
            } //if (isComparable)

            if (!isAscOrder)
                compareResult*=-1;

            if (compareResult<0)
                return -1; //less
            else if (compareResult>0)
                return 1; //more
            else {
            }
        }
        return 0; //equal
    }

    /**
     * Perform logical swap (swap of row indexes).
     *
     * @param startIndex index of the first row.
     * @param endIndex index of the second row.
     */
    protected void swap(int startIndex,int endIndex) {
        if (startIndex==endIndex) return;
        int temp=sortResult[startIndex];
        sortResult[startIndex]=sortResult[endIndex];
        sortResult[endIndex]=temp;
    }

    /**
     * Perform quick sort of part of table data.
     * @param startIndex index of fragment's beginning.
     * @param endIndex index of fragment's ending.
     */
    protected void quickSort(int startIndex,int endIndex) {
        if (startIndex==endIndex) {
            return;
        }
        else if (startIndex==endIndex-1) {
            if (compare(startIndex,endIndex)>0) {
                swap(startIndex,endIndex);
            }
        }
        else {
            int currentIndex=(startIndex+endIndex)/2;
            int lowIndex=startIndex;
            int highIndex=endIndex;
            while (lowIndex<highIndex) {
                if (lowIndex<currentIndex) {
                    if (compare(lowIndex,currentIndex)<=0) {
                        lowIndex++;
                    }
                    else {
                        swap(lowIndex,currentIndex);
                        currentIndex=lowIndex;
                    }
                }

                if (currentIndex<highIndex) {
                    if (compare(currentIndex,highIndex)<=0) {
                        highIndex--;
                    }
                    else {
                        swap(currentIndex,highIndex);
                        currentIndex=highIndex;
                    }
                }
            }
            addIndexPair(new IndexPair(startIndex,currentIndex));
            addIndexPair(new IndexPair(currentIndex,endIndex));
        }
    }

    /**
     * Rerpresents pair of indexes.
     *
     * @author Stanislav Lapitsky
     * @version 1.0
     */
    class IndexPair {
        int startIndex;
        int endIndex;
        public IndexPair(int startIndex, int endIndex) {
            this.startIndex=startIndex;
            this.endIndex=endIndex;
        }
    }

//--------------temporary methods-----------------------------------------------
    public static void main(String[] args) {
        Sorter sorter=new Sorter(createModel(),new int[] {0}, new boolean[] {true});
        int[] res=sorter.sort();

        for (int i=0; i<res.length; i++) {
            System.err.print(res[i]+" ");
        }
    }

    public static TableModel createModel() {
        Object[][] ss=new String[][] {
            {"0","3","1"}
            ,{"0","1","1"}
            ,{"1","9","1"}
            ,{"2","5","1"}
            ,{"0","7","1"}
            ,{"1","9","1"}
        };
        DefaultTableModel model=new DefaultTableModel(ss, new String[] {"1","2"});
        return model;
    }
}