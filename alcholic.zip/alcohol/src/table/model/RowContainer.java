package table.model;

import java.util.ArrayList;
import javax.swing.table.*;

/**
 * This class stores information about EnvelopeTableModel's row.
 *
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class RowContainer {

    /**
     * Index of row of original data.
     */
    protected int originalRowIndex=-1;

    /**
     * Row data.
     */
    protected ArrayList rowData=new ArrayList();

    /**
     * List of row's children (for grouped data).
     */
    protected ArrayList children=new ArrayList();

    /**
     * Parent row (for grouped data).
     */
    protected RowContainer parent=null;

    /**
     * Flag shows whether the row represents original row.
     */
    protected boolean isOriginal=true;

    /**
     * Store group level.
     */
    protected int groupLevel=0;

    /**
     * Constructs new row container instance.
     *
     * @param originalRowIndex index of original row (-1 means the row isn't
     * original).
     * @param isOriginal flag shows whether the row is original.
     * @param columnCount column count.
     */
    public RowContainer(int originalRowIndex,boolean isOriginal,int columnCount) {
        this(originalRowIndex,isOriginal,columnCount,0);
    }

    /**
     * Constructs new row container instance.
     *
     * @param originalRowIndex index of original row (-1 means the row isn't
     * original).
     * @param isOriginal flag shows whether the row is original.
     * @param columnCount column count.
     * @param groupLevel group level number (original rows have level 0).
     */
    public RowContainer(int originalRowIndex,boolean isOriginal,int columnCount,int groupLevel) {
        this.originalRowIndex=originalRowIndex;
        this.isOriginal=isOriginal;
        this.groupLevel=groupLevel;
        if (!isOriginal) {
            for (int i=0; i<columnCount; i++) {
                rowData.add(null);
            }
        }
    }

    /**
     * Sets the row's parent.
     * @param newParent parent row.
     */
    public void setParent(RowContainer newParent) {
        if (parent!=null) {
            parent.children.remove(this);
        }
        parent=newParent;
        if (parent!=null) {
            if (!parent.children.contains(this)) {
                parent.children.add(this);
            }
        }
    }

    /**
     * Gets the row's parent.
     * @return parent row.
     */
    public RowContainer getParent() {
        return parent;
    }

    /**
     * Gets row's child.
     *
     * @param index child index.
     * @return child row.
     */
    public RowContainer getChildAt(int index) {
        return (RowContainer)children.get(index);
    }

    /**
     * Gets count of children.
     * @return
     */
    public int getChildCount() {
        return children.size();
    }

    /**
     * Gets whether the row has original prototype.
     * @return true if the row represents original row data.
     */
    public boolean isOriginal() {
        return isOriginal;
    }

    /**
     * Gets number of original row.
     *
     * @return
     */
    public int getOriginalRowNumber() {
        return originalRowIndex;
    }

    /**
     * Sets number of original row.
     * @param index original row number.
     */
    public void setOriginalRowNumber(int index) {
        originalRowIndex=index;
    }

    /**
     * Gets data from specified row's cell.
     *
     * @param columnIndex index of cell.
     * @return
     */
    public Object getRowData(int columnIndex) {
        return rowData.get(columnIndex);
    }

    /**
     * Sets data to specified cell.
     *
     * @param columnIndex index of cell
     * @param value new cell data.
     */
    public void setRowData(int columnIndex, Object value) {
        if (columnIndex<rowData.size())
            rowData.remove(columnIndex);
        rowData.add(columnIndex,value);
    }

    /**
     * Gets row level.
     *
     * @return
     */
    public int getLevel() {
        return groupLevel;
    }

    public int getCellCount() {
        return rowData.size();
    }

//--- GROUP FUNCTION METHODS ---------------------------------------------------
   /**
    * Removes data from specified column.
    *
    * @param columnIndex
    */
    public void setGroupFunctionEMPTY(int columnIndex) {
        int childCount=getChildCount();
        for(int i=0; i<childCount; i++) {
            RowContainer child=getChildAt(i);
            child.setGroupFunctionEMPTY(columnIndex);
        }
        setRowData(columnIndex,null);
    }

}