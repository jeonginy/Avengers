package table.model.renderer;

import javax.swing.table.*;
import java.awt.*;
import javax.swing.*;
import table.model.*;
import javax.swing.border.*;

/**
 * Simple renderer for grouped data.
 *
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class SimpleRenderer extends JLabel implements TableCellRenderer {

    /**
     * Group backgrounds. Each Color is assotiated with appropriate group level.
     */
    protected Color[] groupBackgrounds;
    /**
     * Group foregrounds. Each Color is assotiated with appropriate group level.
     */
    protected Color[] groupForegrounds;
    /**
     * Group fonts. Each Font is assotiated with appropriate group level.
     */
    protected Font[] groupFonts;

    /**
     * Border for non focused cell.
     */
    protected static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);

    private Color unselectedForeground;
    private Color unselectedBackground;

    private static final int defaultGroupCount=7;

    boolean showGroupText=false;

    /**
     * Constructs new renderer instance with default parameters.
     */
    public SimpleRenderer() {
        this(false);
    }

    /**
     * Constructs new renderer instance with flag indicating whether group
     * function text should be shown.
     *
     * @param showGroupText
     */
    public SimpleRenderer(boolean showGroupText) {
        super();
        this.showGroupText=showGroupText;
        setOpaque(true);
        createDefaults();
    }

    /**
     * Create default colors and fonts.
     */
    protected void createDefaults() {
        groupBackgrounds=new Color[defaultGroupCount];
        groupForegrounds=new Color[defaultGroupCount];
        groupFonts=new Font[defaultGroupCount];
        Font defaultFont=UIManager.getFont("Table.font");
        String fontName=defaultFont.getName();
        int fontStyle=defaultFont.getStyle();
        int fontSize=defaultFont.getSize();
        if (defaultFont.isBold()) {
            fontSize++;
        }
        else {
            fontStyle=fontStyle+Font.BOLD;
        }
        Font font=new Font(fontName,fontStyle,fontSize);
        for (int i=0; i<defaultGroupCount; i++) {
            groupForegrounds[i]=Color.black;
            groupFonts[i]=font;
        }
        groupBackgrounds[0]=Color.white;
        groupBackgrounds[1]=new Color(200,255,255);
        groupBackgrounds[2]=new Color(255,200,255);
        groupBackgrounds[3]=new Color(200,200,255);
        groupBackgrounds[4]=new Color(255,200,200);
        groupBackgrounds[5]=new Color(200,255,200);
        groupBackgrounds[6]=new Color(255,255,200);
    }

    /**
     *  Returns the component used for drawing the cell.  This method is
     *  used to configure the renderer appropriately before drawing.
     *
     * @param	table		the <code>JTable</code> that is asking the
     *				renderer to draw; can be <code>null</code>
     * @param	value		the value of the cell to be rendered.  It is
     *				up to the specific renderer to interpret
     *				and draw the value.  For example, if
     *				<code>value</code>
     *				is the string "true", it could be rendered as a
     *				string or it could be rendered as a check
     *				box that is checked.  <code>null</code> is a
     *				valid value
     * @param	isSelected	true if the cell is to be rendered with the
     *				selection highlighted; otherwise false
     * @param	hasFocus	if true, render cell appropriately.  For
     *				example, put a special border on the cell, if
     *				the cell can be edited, render in the color used
     *				to indicate editing
     * @param	rowIndex        the row index of the cell being drawn.  When
     *				drawing the header, the value of
     *				<code>row</code> is -1
     * @param	column	        the column index of the cell being drawn
     */
    public Component getTableCellRendererComponent(JTable table, Object value,
                                            boolean isSelected, boolean hasFocus,
                                            int rowIndex, int column) {
        int columnIndex=table.convertColumnIndexToModel(column);
        setValue(value);
        if (isSelected) {
           setForeground(table.getSelectionForeground());
           setBackground(table.getSelectionBackground());
        }
        else {
            setForeground(table.getForeground());
            setBackground(table.getBackground());
        }

        setFont(table.getFont());

        if (hasFocus) {
            setBorder( UIManager.getBorder("Table.focusCellHighlightBorder") );
            if (table.isCellEditable(rowIndex, columnIndex)) {
                super.setForeground( UIManager.getColor("Table.focusCellForeground") );
                super.setBackground( UIManager.getColor("Table.focusCellBackground") );
            }
        } else {
            setBorder(noFocusBorder);
        }


        if (!isSelected && !hasFocus && (table.getModel() instanceof EnvelopeTableModel)) {
            EnvelopeTableModel model=(EnvelopeTableModel)table.getModel();
            RowContainer row=model.getRow(rowIndex);
            int level=0;
            level=model.getGroupLevel(columnIndex);
            if (!row.isOriginal()) {
                if (level<row.getLevel())
                    level=row.getLevel();
                setFont(groupFonts[level]);
                if (showGroupText) {
                    setText(createGroupText(columnIndex,rowIndex,model)+" "+getText());
                }
            }

            level=Math.min(level,groupBackgrounds.length-1);
            setBackground(groupBackgrounds[level]);
            setForeground(groupForegrounds[level]);
        }

        return this;
    }

    /**
     * Sets component's text.
     *
     * @param value cell value.
     */
    protected void setValue(Object value) {
        if (value==null) {
            setText("");
        }
        else {
            String text=value.toString();
            setText(text);
        }
    }

    /**
     * Gets group function dependent text.
     *
     * @param columnIndex column index
     * @param rowIndex row index
     * @param model reference to the source model
     * @return
     */
    protected String createGroupText(int columnIndex, int rowIndex,EnvelopeTableModel model) {
        int groupFunction=model.getGroupFunction(columnIndex);
        return getFunctionText(groupFunction);
    }

    public String getFunctionText(int function) {
        switch (function) {
            case EnvelopeTableModel.GROUP_FUNCTION_EMPTY :
                break;
            case EnvelopeTableModel.GROUP_FUNCTION_COUNT :
                return "COUNT:";
            case EnvelopeTableModel.GROUP_FUNCTION_MIN :
                return "MIN:";
            case EnvelopeTableModel.GROUP_FUNCTION_MAX :
                return "MAX:";
            case EnvelopeTableModel.GROUP_FUNCTION_SUM :
                return "SUM:";
            case EnvelopeTableModel.GROUP_FUNCTION_AVG :
                return "AVG:";
            default :
                break;
        }
        return "";
    }

    /**
     * Sets group data backgrounds.
     * @param backgrounds color list.
     */
    public void setGroupBackgrounds(Color[] backgrounds) {
        this.groupBackgrounds=backgrounds;
    }

    /**
     * Sets group data foregrounds.
     * @param foregrounds color list.
     */
    public void setGroupForegrounds(Color[] foregrounds) {
        this.groupForegrounds=foregrounds;
    }


    /**
     * Sets group data fonts.
     * @param fonts font list.
     */
    public void setGroupFonts(Font[] fonts) {
        this.groupFonts=fonts;
    }

    /**
     * Gets group data backgrounds.
     * @return
     */
    public Color[] getGroupBackgrounds() {
        return this.groupBackgrounds;
    }


    /**
     * Gets group data foregrounds.
     * @return
     */
    public Color[] getGroupForegrounds() {
        return this.groupForegrounds;
    }

    /**
     * Gets group data fonts.
     * @return
     */
    public Font[] getGroupFonts() {
        return this.groupFonts;
    }

//------------------------------------------------------------------------------
    /**
     * Overridden for performance reasons.
     * See the <a href="#override">Implementation Note</a>
     * for more information.
     */
    public boolean isOpaque() {
        Color back = getBackground();
        Component p = getParent();
        if (p != null) {
            p = p.getParent();
        }
        // p should now be the JTable.
        boolean colorMatch = (back != null) && (p != null) &&
            back.equals(p.getBackground()) &&
                        p.isOpaque();
        return !colorMatch && super.isOpaque();
    }

    /**
     * Overridden for performance reasons.
     * See the <a href="#override">Implementation Note</a>
     * for more information.
     */
    public void validate() {}

    /**
     * Overridden for performance reasons.
     * See the <a href="#override">Implementation Note</a>
     * for more information.
     */
    public void revalidate() {}

    /**
     * Overridden for performance reasons.
     * See the <a href="#override">Implementation Note</a>
     * for more information.
     */
    public void repaint(long tm, int x, int y, int width, int height) {}

    /**
     * Overridden for performance reasons.
     * See the <a href="#override">Implementation Note</a>
     * for more information.
     */
    public void repaint(Rectangle r) { }

    /**
     * Overridden for performance reasons.
     * See the <a href="#override">Implementation Note</a>
     * for more information.
     */
    protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
        // Strings get interned...
        if (propertyName=="text") {
            super.firePropertyChange(propertyName, oldValue, newValue);
        }
    }

    /**
     * Overridden for performance reasons.
     * See the <a href="#override">Implementation Note</a>
     * for more information.
     */
    public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) { }
}