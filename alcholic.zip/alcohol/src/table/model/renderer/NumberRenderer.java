package table.model.renderer;

import javax.swing.JLabel;
import java.text.*;

/**
 * Shows formatted numbers in the grouped data.
 *
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class NumberRenderer extends SimpleRenderer {

    /**
     * Default number format.
     */
    protected NumberFormat format=new DecimalFormat("#,###.00");

    /**
     * Creates new instance of renderer.
     */
    public NumberRenderer() {
        this(false);
    }
    /**
     * Constructs new renderer instance with flag indicating whether group
     * function text should be shown.
     *
     * @param showGroupText
     */
    public NumberRenderer(boolean showGroupText) {
        super(showGroupText);
    }

    /**
     * Sets component's text.
     *
     * @param value cell value.
     */
    protected void setValue(Object value) {
        if (value==null) {
            super.setValue(value);
        }
        else {
            if (value instanceof Number) {
                setHorizontalAlignment(JLabel.RIGHT);
                setText(format.format(value));
            }
            else {
                setText(value.toString());
            }
        }
    }

    /**
     * Sets number format.
     *
     * @param format
     */
    public void setFormat(NumberFormat format) {
        this.format=format;
    }

    /**
     * Gets current number format.
     * @return
     */
    public NumberFormat getFormat() {
        return format;
    }
}