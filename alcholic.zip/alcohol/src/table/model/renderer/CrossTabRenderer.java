package table.model.renderer;

import javax.swing.*;
import java.awt.*;
import table.model.*;
import java.text.*;

/**
 * Shows crossed data.
 *
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class CrossTabRenderer extends NumberRenderer {

    /**
     * Creates default instance.
     */
    public CrossTabRenderer() {
        this(true);
    }
    /**
     * Creates renderer instance with specified parameter.
     * @param showGroupText shows group functions text if true.
     */
    public CrossTabRenderer(boolean showGroupText) {
        super(showGroupText);
    }
    /**
     *  Returns the component used for drawing the cell.  This method is
     *  used to configure the renderer appropriately before drawing.
     *
     * @param	table		the <code>JTable</code> that is asking the
     *				renderer to draw; can be <code>null</code>
     * @param	value		the value of the cell to be rendered.  It is
     *				up to the specific renderer to interpret
     *				and draw the value.  For example, if
     *				<code>value</code>
     *				is the string "true", it could be rendered as a
     *				string or it could be rendered as a check
     *				box that is checked.  <code>null</code> is a
     *				valid value
     * @param	isSelected	true if the cell is to be rendered with the
     *				selection highlighted; otherwise false
     * @param	hasFocus	if true, render cell appropriately.  For
     *				example, put a special border on the cell, if
     *				the cell can be edited, render in the color used
     *				to indicate editing
     * @param	rowIndex        the row index of the cell being drawn.  When
     *				drawing the header, the value of
     *				<code>row</code> is -1
     * @param	column	        the column index of the cell being drawn
     */
    public Component getTableCellRendererComponent(JTable table, Object value,
                                            boolean isSelected, boolean hasFocus,
                                            int rowIndex, int column) {
        super.getTableCellRendererComponent(table,value,isSelected,hasFocus,rowIndex,column);
        if (!isSelected && !hasFocus && (table.getModel() instanceof EnvelopeTableModel)) {
            EnvelopeTableModel model=(EnvelopeTableModel)table.getModel();
            if ((rowIndex==0) || (column==0) || (rowIndex==model.getRowCount()-1) || (column==model.getColumnCount()-1)) {
                setBackground(groupBackgrounds[1]);
                setForeground(groupForegrounds[1]);
                setFont(groupFonts[1]);
                if (showGroupText) {
                    if ((rowIndex==0) && (column==model.getColumnCount()-1)) {
                        setText(getFunctionText(model.getVerticalCrossTabFunction())); //v
                    }
                    else if ((column==0) && (rowIndex==model.getRowCount()-1)) {
                        setText(getFunctionText(model.getHorizontalCrossTabFunction())); //h
                    }
                }
            }
            else {
                setForeground(table.getForeground());
                setBackground(table.getBackground());
                setFont(table.getFont());
            }

            if ((rowIndex==model.getRowCount()-1) || (column==model.getColumnCount()-1)) {
                setHorizontalAlignment(JLabel.RIGHT);
            }
            else if (rowIndex==0) {
                setHorizontalAlignment(JLabel.CENTER);
            }
            else if (column==0) {
                setHorizontalAlignment(JLabel.LEFT);
            }
            else {
                setHorizontalAlignment(JLabel.LEFT);
                if (model.getRegim()==EnvelopeTableModel.MODEL_REGIM_CROSSTAB) {
                    int col=model.getCrossColumnIndex();
                    Class crossClass=model.getOriginalModel().getColumnClass(col);
                    if (Number.class.isAssignableFrom(crossClass)) {
                        setHorizontalAlignment(JLabel.RIGHT);
                    }
                }
            }
        }
        return this;
    }

}