package table.model;

import javax.swing.table.*;
import javax.swing.event.*;
import java.util.*;
import table.model.exception.*;

/**
 * EnvelopeTableModel incapsulates another TableModel and gives possibility to
 * perform reordering and grouping of data without changing original data.
 * It also allows to set group functions for grouped data.
 *
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class EnvelopeTableModel implements TableModel, TableModelListener {

    public static final int GROUP_FUNCTION_EMPTY=0;
    public static final int GROUP_FUNCTION_COUNT=1;

    public static final int GROUP_FUNCTION_MAX=2;
    public static final int GROUP_FUNCTION_MIN=3;

    public static final int GROUP_FUNCTION_SUM=4;
    public static final int GROUP_FUNCTION_AVG=5;

    public static final int MODEL_REGIM_ORIGINAL=0;
    public static final int MODEL_REGIM_SORT=1;
    public static final int MODEL_REGIM_GROUP=2;
    public static final int MODEL_REGIM_CROSSTAB=3;

    public static final int DIRECTION_HORIZONTAL=0;
    public static final int DIRECTION_VERTICAL=1;

    /**
     * Model regim (original, sort, group, crosstab).
     */
    protected int regim=0;
    /**
     * Original (incapsulated) model.
     */
    protected TableModel originalModel;

    /**
     * List of attached TableModelListeners.
     */
    protected ArrayList listenersList=new ArrayList();

    /**
     * Sort columns.
     */
    protected int[] sortColumnIndexes=new int[0];

    /**
     * Sort orders for each column from sortColumnIndexes.
     */
    protected boolean[] sortOrders;

    /**
     * Group columns.
     */
    protected int[] groupColumnIndexes=new int[0];

    /**
     * Sort orders for each column from groupColumnIndexes.
     */
    protected boolean[] groupOrders;

    /**
     * Group functions attached to columns.
     */
    protected int[] groupFunctions;

    /**
     * Containes model's rows.
     */
    protected ArrayList modelData;

    /**
     * Data sorter.
     */
    protected Sorter sorter=new Sorter();
    /**
     * Data grouper.
     */
    protected Grouper grouper=new Grouper();
    protected int verticalColumnNumber;
    protected boolean verticalSortOrder;
    protected int horizontalColumnNumber;
    protected boolean horizontalSortOrder;
    protected int crossColumnNumber;

    protected int verticalCrossTabFunction=GROUP_FUNCTION_EMPTY;
    protected int horizontalCrossTabFunction=GROUP_FUNCTION_EMPTY;
    /**
     * Constructs a new instance with specified original TableModel.
     * @param source original TableModel.
     */
    public EnvelopeTableModel(TableModel source) {
        originalModel=source;
        originalModel.addTableModelListener(this);
        reset();
    }

    /**
     * Gets original TableModel
     * @return
     */
    public TableModel getOriginalModel() {
        return originalModel;
    }

//--- TableModel's methods -----------------------------------------------------
    /**
     * Returns the number of rows in the model.
     *
     * @return the number of rows in the model
     */
    public int getRowCount() {
        //return originalModel.getRowCount();
        return modelData.size();
    }

    /**
     * Returns the number of columns in the model.
     *
     * @return the number of columns in the model
     */
    public int getColumnCount() {
        if (regim!=MODEL_REGIM_CROSSTAB)
            return originalModel.getColumnCount();
        else {
            RowContainer row=(RowContainer)modelData.get(0);
            return row.getCellCount();
        }
    }

    /**
     * Returns the name of the column at columnIndex.
     *
     * @param	columnIndex	the index of the column
     * @return  the name of the column
     */
    public String getColumnName(int columnIndex) {
        return originalModel.getColumnName(columnIndex);
    }

    /**
     * Returns the most specific superclass for all the cell values
     * in the column.
     *
     * @param columnIndex  the index of the column
     * @return the common ancestor class of the object values in the model.
     */
    public Class getColumnClass(int columnIndex) {
        if (regim!=MODEL_REGIM_CROSSTAB)
            return originalModel.getColumnClass(columnIndex);
        else {
            return Object.class;
        }
    }

    /**
     * Returns true if the cell at <code>rowIndex</code> and
     * <code>columnIndex</code>
     * is editable.  Otherwise, <code>setValueAt</code> on the cell will not
     * change the value of that cell.
     *
     * @param	rowIndex	the row whose value to be queried
     * @param	columnIndex	the column whose value to be queried
     * @return	true if the cell is editable
     */
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        RowContainer row=(RowContainer)modelData.get(rowIndex);
        if (row.isOriginal()) {
            return originalModel.isCellEditable(row.getOriginalRowNumber(),columnIndex);
        }
        else {
            return false;
        }
    }

    /**
     * Returns the value for the cell at <code>columnIndex</code> and
     * <code>rowIndex</code>.
     *
     * @param	rowIndex	the row whose value is to be queried
     * @param	columnIndex 	the column whose value is to be queried
     * @return	the value Object at the specified cell
     */
    public Object getValueAt(int rowIndex, int columnIndex) {
        RowContainer row=(RowContainer)modelData.get(rowIndex);
        if (row.isOriginal()) {
            return originalModel.getValueAt(row.getOriginalRowNumber(),columnIndex);
        }
        else {
            return row.getRowData(columnIndex);
        }
    }

    /**
     * Sets the value in the cell at <code>columnIndex</code> and
     * <code>rowIndex</code> to <code>aValue</code>.
     *
     * @param	aValue		 the new value
     * @param	rowIndex	 the row whose value is to be changed
     * @param	columnIndex 	 the column whose value is to be changed
     */
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        RowContainer row=(RowContainer)modelData.get(rowIndex);
        if (row.isOriginal()) {
            originalModel.setValueAt(aValue,row.getOriginalRowNumber(),columnIndex);
        }
    }

    /**
     * Adds a listener to the list that is notified each time a change
     * to the data model occurs.
     *
     * @param	l		the TableModelListener
     */
    public void addTableModelListener(TableModelListener l) {
        listenersList.add(l);
    }

    /**
     * Removes a listener from the list that is notified each time a
     * change to the data model occurs.
     *
     * @param	l		the TableModelListener
     */
    public void removeTableModelListener(TableModelListener l) {
        listenersList.remove(l);
    }
//--- TableModel's methods -----------------------------------------------------

//--- TableModelListener's methods ---------------------------------------------
   /**
    * When original model is changed we have to refresh data.
    * @param e change event.
    */
    public void tableChanged(TableModelEvent e) {
        switch (regim) {
            case MODEL_REGIM_SORT :
                refreshSort();
                break;
            case MODEL_REGIM_GROUP :
                refreshGroup();
                break;
            case MODEL_REGIM_CROSSTAB :
                System.err.println("Not implemented!");
                break;
        }
    }

//--- TableModelListener's methods ---------------------------------------------

   /**
    * Gets originnal row number for specified row.
    * @param rowNumber number of model's row.
    * @return original model's row number.
    */
    protected int getOriginalRowNumber(int rowNumber) {
        RowContainer row=(RowContainer)modelData.get(rowNumber);
        if (row.isOriginal)
            return row.getOriginalRowNumber();
        else
            return -1;
    }

    /**
     * Sets sort regim.
     * @param sortColumnIndexes sort column indexes.
     * @param sortOrders sort orders.
     * @throws SortException
     */
    public void setSort(int[] sortColumnIndexes,boolean[] sortOrders) throws SortException {
        this.groupColumnIndexes=new int[0];
        this.sortColumnIndexes=sortColumnIndexes;
        this.sortOrders=sortOrders;
        int columnCount=getColumnCount();
        sorter.setSourceTableModel(originalModel);
        sorter.setSort(sortColumnIndexes,sortOrders);
        int[] results=sorter.sort();
        modelData=new ArrayList(results.length);
        for (int i=0; i<results.length; i++) {
            modelData.add(new RowContainer(results[i],true,columnCount));
        }
        regim=MODEL_REGIM_SORT;
        fireTableDataChanged();
    }

    /**
     * Sets group regim.
     * @param groupColumnIndexes group column indexes.
     * @param groupOrders orders for grouped columns.
     * @throws GroupException
     */
    public void setGroup(int[] groupColumnIndexes,boolean[] groupOrders) throws GroupException {
        this.sortColumnIndexes=new int[0];
        this.groupColumnIndexes=groupColumnIndexes;
        this.groupOrders=groupOrders;
        grouper.setSourceTableModel(originalModel);
        grouper.setGroup(groupColumnIndexes,groupOrders);
        modelData=grouper.group();

        groupFunctions=new int[originalModel.getColumnCount()];
        for (int i=0; i<groupFunctions.length; i++) {
            groupFunctions[i]=GROUP_FUNCTION_EMPTY;
        }
        regim=MODEL_REGIM_GROUP;
        fireTableDataChanged();
    }

    /**
     * Gets group function assotiated with specified column.
     *
     * @param columnIndex index of column.
     * @return group function.
     */
    public int getGroupFunction(int columnIndex) {
        if (groupFunctions!=null)
            return groupFunctions[columnIndex];
        else
            return GROUP_FUNCTION_EMPTY;
    }

    /**
     * Sets group function for specified column.
     *
     * @param columnIndex index of column.
     * @param groupFunction group function.
     * @throws GroupException
     */
    public void setGroupFunction(int columnIndex,int groupFunction) throws GroupException {
        if (regim!=MODEL_REGIM_GROUP) {
            throw new GroupException("Can't set group function! Call setGroup(...) first.");
        }
        Class columnClass=getColumnClass(columnIndex);
        groupFunctions[columnIndex]=groupFunction;
        if ((groupFunction==4) || (groupFunction==5)) {
            if (!Number.class.isAssignableFrom(columnClass)) {
                throw new GroupException("Group function can't be applied to column class "+columnClass.getName());
            }
        }
        if ((groupFunction==2) || (groupFunction==3)) {
            if (!Comparable.class.isAssignableFrom(columnClass)) {
                throw new GroupException("Group function can't be applied to column class "+columnClass.getName());
            }
        }
        switch (groupFunction) {
            case GROUP_FUNCTION_EMPTY:
                setGroupFunctionEMPTY(columnIndex);
                break;
            case GROUP_FUNCTION_COUNT:
                setGroupFunctionCOUNT(columnIndex);
                break;
            case GROUP_FUNCTION_MIN :
                setGroupFunctionMIN(columnIndex);
                break;
            case GROUP_FUNCTION_MAX :
                setGroupFunctionMAX(columnIndex);
                break;
            case GROUP_FUNCTION_SUM :
                setGroupFunctionSUM(columnIndex);
                break;
            case GROUP_FUNCTION_AVG :
                setGroupFunctionAVG(columnIndex);
                break;
            default :
                System.err.println("");
        }
    }

    /**
     * Sets group function EMPTY to specified column.
     *
     * @param columnIndex index of column.
     */
    protected void setGroupFunctionEMPTY(int columnIndex) {
        int rowCount=getRowCount();
        for (int i=0; i<rowCount; i++) {
            RowContainer row=(RowContainer)modelData.get(i);
            if (!row.isOriginal()) {
                row.setRowData(columnIndex,null);
            }
        }
    }

    /**
     * Sets group function COUNT to specified column.
     *
     * @param columnIndex index of column.
     */
    protected void setGroupFunctionCOUNT(int columnIndex) {
        int rowCount=getRowCount();
        int[] counts=new int[groupColumnIndexes.length+2];
        for (int i=0; i<counts.length; i++) {
            counts[i]=0;
        }
        for (int i=0; i<rowCount; i++) {
            RowContainer row=(RowContainer)modelData.get(i);
            if (row.isOriginal()) {
                counts[0]++;
            }
            else {
                int level=row.groupLevel;
                int count=counts[level-1];
                counts[level]+=count;
                row.setRowData(columnIndex,new Integer(count));
                for (int j=0; j<level; j++) {
                    counts[j]=0;
                }
            }
        }
    }

    /**
     * Sets group function MAX to specified column.
     *
     * @param columnIndex index of column.
     */
    protected void setGroupFunctionMAX(int columnIndex) {
        int rowCount=getRowCount();
        Object[] maxs=new Object[groupColumnIndexes.length+2];
        for (int i=0; i<maxs.length; i++) {
            maxs[i]=null;
        }
        for (int i=0; i<rowCount; i++) {
            RowContainer row=(RowContainer)modelData.get(i);
            if (row.isOriginal()) {
                Comparable currentValue=(Comparable)getValueAt(i,columnIndex);
                if (maxs[0]==null) {
                    maxs[0]=currentValue;
                }
                else if (currentValue==null) {
                    //do nothing
                }
                else if (currentValue.compareTo(maxs[0])>0) {
                    maxs[0]=currentValue;
                }
            }
            else { //not original
                int level=row.groupLevel;
                Comparable previousMax=(Comparable)maxs[level-1];
                if (maxs[level]==null) {
                    maxs[level]=previousMax;
                }
                else if (previousMax==null) {
                    //do nothing
                }
                else {
                    if ( ((Comparable)maxs[level]).compareTo(previousMax)<0) {
                        maxs[level]=previousMax;
                    }
                }
                row.setRowData(columnIndex,previousMax);
                for (int j=0; j<level; j++) {
                    maxs[j]=null;
                }
            } //if (row.isOriginal()
        }
    }

    /**
     * Sets group function MIN to specified column.
     *
     * @param columnIndex index of column.
     */
    protected void setGroupFunctionMIN(int columnIndex) {
        int rowCount=getRowCount();
        Object[] mins=new Object[groupColumnIndexes.length+2];
        for (int i=0; i<mins.length; i++) {
            mins[i]=null;
        }
        for (int i=0; i<rowCount; i++) {
            RowContainer row=(RowContainer)modelData.get(i);
            if (row.isOriginal()) {
                Comparable currentValue=(Comparable)getValueAt(i,columnIndex);
                if (mins[0]==null) {
                    mins[0]=currentValue;
                }
                else if (currentValue==null) {
                    //do nothing
                }
                else if (currentValue.compareTo(mins[0])<0) {
                    mins[0]=currentValue;
                }
            }
            else { //not original
                int level=row.groupLevel;
                Comparable previousMin=(Comparable)mins[level-1];
                if (previousMin==null) {
                    //mins[level]=previousMin;
                }
                else if (mins[level]==null) {
                    mins[level]=previousMin;
                }
                else {
                    if ( ((Comparable)mins[level]).compareTo(previousMin)>0) {
                        mins[level]=previousMin;
                    }
                }
                row.setRowData(columnIndex,previousMin);
                for (int j=0; j<level; j++) {
                    mins[j]=null;
                }
            } //if (row.isOriginal()
        }
    }

    /**
     * Sets group function SUM to specified column.
     *
     * @param columnIndex index of column.
     */
    protected void setGroupFunctionSUM(int columnIndex) {
        int rowCount=getRowCount();
        Class columnClass=getColumnClass(columnIndex);
        boolean isReal=false;
        if ((Double.class.isAssignableFrom(columnClass)) || (Float.class.isAssignableFrom(columnClass))) {
            isReal=true;
        }
        double[] sumsDouble=new double[groupColumnIndexes.length+2];
        long[] sumsLong=new long[groupColumnIndexes.length+2];
        for (int i=0; i<sumsDouble.length; i++) {
            sumsDouble[i]=0;
            sumsLong[i]=0;
        }
        for (int i=0; i<rowCount; i++) {
            RowContainer row=(RowContainer)modelData.get(i);
            if (row.isOriginal()) {
                Number number=((Number)getValueAt(i,columnIndex));
                if (number!=null) {
                    sumsDouble[0]+=number.doubleValue();
                    sumsLong[0]+=number.longValue();
                }
            }
            else {
                int level=row.groupLevel;
                double sumDouble=sumsDouble[level-1];
                long sumLong=sumsLong[level-1];
                sumsDouble[level]+=sumDouble;
                sumsLong[level]+=sumLong;
                if (isReal) {
                    row.setRowData(columnIndex,new Double(sumDouble));
                }
                else {
                    row.setRowData(columnIndex,new Long(sumLong));
                }
                for (int j=0; j<level; j++) {
                    sumsDouble[j]=0;
                    sumsLong[j]=0;
                }
            }
        }
    }

    /**
     * Sets group function AVG to specified column.
     *
     * @param columnIndex index of column.
     */
    protected void setGroupFunctionAVG(int columnIndex) {
        int rowCount=getRowCount();
        Class columnClass=getColumnClass(columnIndex);
        double[] sumsDouble=new double[groupColumnIndexes.length+2];
        int[] counts=new int[groupColumnIndexes.length+2];
        for (int i=0; i<sumsDouble.length; i++) {
            sumsDouble[i]=0;
        }
        for (int i=0; i<rowCount; i++) {
            RowContainer row=(RowContainer)modelData.get(i);
            if (row.isOriginal()) {
                Number n=(Number)getValueAt(i,columnIndex);
                if (n!=null)
                    sumsDouble[0]+=n.doubleValue();
                counts[0]++;
            }
            else {
                int level=row.groupLevel;
                double sumDouble=sumsDouble[level-1];
                int count=counts[level-1];
                sumsDouble[level]+=sumDouble;
                counts[level]+=count;
                row.setRowData(columnIndex,new Double(sumDouble/count));
                for (int j=0; j<level; j++) {
                    sumsDouble[j]=0;
                    counts[j]=0;
                }
            }
        }
    }

    /**
     * Restores original data order.
     */
    public void reset() {
        int rowCount=originalModel.getRowCount();
        int columnCount=getColumnCount();
        modelData=new ArrayList(rowCount);
        groupFunctions=null;
        for (int i=0; i<rowCount; i++) {
            modelData.add(new RowContainer(i,true,columnCount));
        }
        regim=MODEL_REGIM_ORIGINAL;
    }

    /**
     * Refresh grouping.
     */
    public void refreshGroup() {
        if (regim==MODEL_REGIM_GROUP) {
            int[] currentGroup=groupColumnIndexes;
            boolean[] currentOrders=groupOrders;
            int[] currentGroupFunctions=groupFunctions;
            reset();
            try {
                setGroup(currentGroup,currentOrders);
                for (int i=0; i<currentGroupFunctions.length; i++) {
                    setGroupFunction(i,currentGroupFunctions[i]);
                }
            }
            catch (GroupException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Refresh sort.
     */
    public void refreshSort() {
        if (regim==MODEL_REGIM_SORT) {
            int[] currentSort=sortColumnIndexes;
            boolean[] currentOrders=sortOrders;
            reset();
            try {
                setSort(currentSort,currentOrders);
            }
            catch (SortException ex) {
                ex.printStackTrace();
            }
        }
    }

    /**
     * Gets root of grouped data (the last row in grouped table).
     */
    public RowContainer getGroupRoot() {
        return (RowContainer)modelData.get(modelData.size()-1);
    }

    /**
     * Gets row data for specified row index.
     * @param rowIndex index of row.
     * @return row data.
     */
    public RowContainer getRow(int rowIndex) {
        return (RowContainer)modelData.get(rowIndex);
    }

    /**
     * Gets group columns.
     *
     * @return column indexes array.
     */
    public int[] getGroupColumns() {
        return groupColumnIndexes;
    }

    /**
     * Gets group orders.
     *
     * @return orders array.
     */
    public boolean[] getGroupOrders() {
        return groupOrders;
    }

    /**
     * Gets level of grouped data.
     *
     * @param columnIndex index of grouped column.
     * @return
     */
    public int getGroupLevel(int columnIndex) {
        int cnt=groupColumnIndexes.length;
        for (int i=cnt-1; i>=0; i--) {
            if (columnIndex==groupColumnIndexes[i]) {
                return cnt-i;
            }
        }
        return 0;
    }

    /**
     * Noifies all table model listeners about data changes.
     */
    public void fireTableDataChanged() {
        //listenersList
        TableModelEvent event=new TableModelEvent(this);
        int size=listenersList.size();
        for (int i=0; i<size; i++) {
            TableModelListener l=(TableModelListener)listenersList.get(i);
            l.tableChanged(event);
        }
    }

    /**
     * Noifies all table model listeners about data changes.
     *
     * @param event changes event.
     */
    public void fireTableModelEvent(TableModelEvent event) {
        int size=listenersList.size();
        for (int i=0; i<size; i++) {
            TableModelListener l=(TableModelListener)listenersList.get(i);
            l.tableChanged(event);
        }
    }

    /**
     * Sets cross tab regim.
     *
     * @param verticalColumnNumber index of vertical column in the original model.
     * @param verticalSortOrder vertical column sort order.
     * @param horizontalColumnNumber index of horizontal column in the original model.
     * @param horizontalSortOrder horizontal column sort order.
     * @param crossColumnNumber index of cross column in the original model.
     */
    public void setCrossTab(int verticalColumnNumber,boolean verticalSortOrder,int horizontalColumnNumber,boolean horizontalSortOrder,int crossColumnNumber) {
        this.verticalColumnNumber=verticalColumnNumber;
        this.verticalSortOrder=verticalSortOrder;
        this.horizontalColumnNumber=horizontalColumnNumber;
        this.horizontalSortOrder=horizontalSortOrder;
        this.crossColumnNumber=crossColumnNumber;

        CrossTabCreator crossTabCreator=new CrossTabCreator(this.originalModel);
        crossTabCreator.setCrossTab(verticalColumnNumber,verticalSortOrder,horizontalColumnNumber,horizontalSortOrder,crossColumnNumber);
        modelData=crossTabCreator.createCrossTab();
        regim=MODEL_REGIM_CROSSTAB;
        fireTableDataChanged();
    }

    /**
     * Gets current model regim.
     * @return
     */
    public int getRegim() {
        return regim;
    }

    /**
     * Gets original model's column index for verticl cross column.
     * @return
     */
    public int getVerticalCrossTabColumnIndex() {
        return verticalColumnNumber;
    }
    /**
     * Gets sort order of vertical column.
     * @return
     */
    public boolean getVerticalCrossTabColumnOrder() {
        return verticalSortOrder;
    }

    /**
     * Gets original model's column index for cross column.
     * @return
     */
    public int getCrossColumnIndex() {
        return crossColumnNumber;
    }

    /**
     * Gets original model's column index for horizontal cross column.
     * @return
     */
    public int getHorizontalCrossTabColumnIndex() {
        return horizontalColumnNumber;
    }
    /**
     * Gets sort order of horizontal column.
     * @return
     */
    public boolean getHorizontalCrossTabColumnOrder() {
        return horizontalSortOrder;
    }

    /**
     * Sets group function for cross data.
     * @param function group function
     * @param direction HORIZONTAL or VERTICAL
     * @throws CrossTabException
     */
    public void setCrossTabFunction(int function, int direction) throws CrossTabException {
        if (regim!=MODEL_REGIM_CROSSTAB) {
            throw new CrossTabException("Can't set group function! Call setGroup(...) first.");
        }
        int columnIndex=crossColumnNumber;
        Class columnClass=originalModel.getColumnClass(columnIndex);
        if ((function==4) || (function==5)) {
            if (!Number.class.isAssignableFrom(columnClass)) {
                throw new CrossTabException("Function can't be applied to column class "+columnClass.getName());
            }
        }
        if ((function==2) || (function==3)) {
            if (!Comparable.class.isAssignableFrom(columnClass)) {
                throw new CrossTabException("Function can't be applied to column class "+columnClass.getName());
            }
        }

        if (direction==DIRECTION_HORIZONTAL) {
           horizontalCrossTabFunction=function;
        }
        else { //vertical
            verticalCrossTabFunction=function;
        }
        switch (function) {
            case GROUP_FUNCTION_EMPTY:
                setCrossTabFunctionEMPTY(direction);
                break;
            case GROUP_FUNCTION_COUNT:
                setCrossTabFunctionCOUNT(direction);
                break;
            case GROUP_FUNCTION_MIN :
                setCrossTabFunctionMIN(direction);
                break;
            case GROUP_FUNCTION_MAX :
                setCrossTabFunctionMAX(direction);
                break;
            case GROUP_FUNCTION_SUM :
                setCrossTabFunctionSUM(direction);
                break;
            case GROUP_FUNCTION_AVG :
                setCrossTabFunctionAVG(direction);
                break;
            default :
                System.err.println("");
        }
   }

   /**
    * Sets empty cross function.
    * @param direction HORIZONTAL or VERTICAL
    */
   protected void setCrossTabFunctionEMPTY(int direction) {
       int rowCount=getRowCount();
       RowContainer bottomRow=(RowContainer)modelData.get(getRowCount()-1);
       int size=bottomRow.getCellCount();
       //horizontal
       if (direction==DIRECTION_HORIZONTAL) {
           for (int i=1; i<size-1; i++) {
               bottomRow.setRowData(i,null);
           }
       }
       else {
           //vertical
           for (int i=1; i<rowCount-1; i++) {
               RowContainer row=(RowContainer)modelData.get(i);
               row.setRowData(size-1,null);
           }
       }
   }

   /**
    * Sets COUNT cross function.
    * @param direction HORIZONTAL or VERTICAL
    */
   protected void setCrossTabFunctionCOUNT(int direction) {
       int rowCount=getRowCount();
       RowContainer bottomRow=(RowContainer)modelData.get(getRowCount()-1);
       int size=bottomRow.getCellCount();
       //horizontal
       if (direction==DIRECTION_HORIZONTAL) {
           for (int i=1; i<size-1; i++) {
               bottomRow.setRowData(i,new Integer(rowCount-2));
           }
       }
       else {
           //vertical
           for (int i=1; i<rowCount-1; i++) {
               RowContainer row=(RowContainer)modelData.get(i);
               row.setRowData(size-1,new Integer(size-2));
           }
       }
   }

   /**
    * Sets MIN cross function.
    * @param direction HORIZONTAL or VERTICAL
    */
   protected void setCrossTabFunctionMIN(int direction) {
       int rowCount=getRowCount();
       RowContainer bottomRow=(RowContainer)modelData.get(getRowCount()-1);
       int size=bottomRow.getCellCount();
       //horizontal
       if (direction==DIRECTION_HORIZONTAL) {
           if (rowCount>=3) {
               RowContainer firstRow=(RowContainer)modelData.get(1);
               for (int i=1; i<size-1; i++) {
                   bottomRow.setRowData(i,firstRow.getRowData(i));
               }
               for (int i=2; i<rowCount-1; i++) {
                   RowContainer row=(RowContainer)modelData.get(i);
                   for (int j=1; j<size-1; j++) {
                       Comparable currentMin=(Comparable)bottomRow.getRowData(j);
                       Comparable currentValue=(Comparable)row.getRowData(j);
                       if (currentMin!=null) {
                           if ((currentValue!=null) && (currentMin.compareTo(currentValue)>0)) {
                               bottomRow.setRowData(j,currentValue);
                           }
                       }
                       else {
                           bottomRow.setRowData(j,currentValue);
                       }
                   }
               }
           }
       } //direction
       else {
           //vertical
           if (size>=3) {
               for (int i=1; i<rowCount-1; i++) {
                   RowContainer row=(RowContainer)modelData.get(i);
                   for (int j=1; j<size-1; j++) {
                       Comparable currentMin=(Comparable)row.getRowData(size-1);
                       Comparable currentValue=(Comparable)row.getRowData(j);
                       if (currentMin!=null) {
                           if ((currentValue!=null) && (currentMin.compareTo(currentValue)>0)) {
                               row.setRowData(size-1,currentValue);
                           }
                       }
                       else {
                           row.setRowData(size-1,currentValue);
                       }
                   }
               }
           }
       }
   }

   /**
    * Sets MAX cross function.
    * @param direction HORIZONTAL or VERTICAL
    */
   protected void setCrossTabFunctionMAX(int direction) {
       int rowCount=getRowCount();
       RowContainer bottomRow=(RowContainer)modelData.get(getRowCount()-1);
       int size=bottomRow.getCellCount();
       if (direction==DIRECTION_HORIZONTAL) {
           //horizontal
           if (rowCount>=3) {
               RowContainer firstRow=(RowContainer)modelData.get(1);
               for (int i=1; i<size-1; i++) {
                   bottomRow.setRowData(i,firstRow.getRowData(i));
               }
               for (int i=2; i<rowCount-1; i++) {
                   RowContainer row=(RowContainer)modelData.get(i);
                   for (int j=1; j<size-1; j++) {
                       Comparable currentMax=(Comparable)bottomRow.getRowData(j);
                       Comparable currentValue=(Comparable)row.getRowData(j);
                       if (currentMax!=null) {
                           if ((currentValue!=null) && (currentMax.compareTo(currentValue)<0)) {
                               bottomRow.setRowData(j,currentValue);
                           }
                       }
                       else {
                           bottomRow.setRowData(j,currentValue);
                       }
                   }
               }
           }
       }
       else {
           //vertical
           if (size>=3) {
               for (int i=1; i<rowCount-1; i++) {
                   RowContainer row=(RowContainer)modelData.get(i);
                   for (int j=1; j<size-1; j++) {
                       Comparable currentMax=(Comparable)row.getRowData(size-1);
                       Comparable currentValue=(Comparable)row.getRowData(j);
                       if (currentMax!=null) {
                           if ((currentValue!=null) && (currentMax.compareTo(currentValue)<0)) {
                               row.setRowData(size-1,currentValue);
                           }
                       }
                       else {
                           row.setRowData(size-1,currentValue);
                       }
                   }
               }
           }
       }
   }

   /**
    * Sets SUM cross function
    * @param direction  HORIZONTAL or VERTICAL
    */
   protected void setCrossTabFunctionSUM(int direction) {
       int rowCount=getRowCount();
       //horizontal
       RowContainer bottomRow=(RowContainer)modelData.get(getRowCount()-1);
       int size=bottomRow.getCellCount();
       if (direction==DIRECTION_HORIZONTAL) {
           //horizontal
           if (rowCount>=3) {
               RowContainer firstRow=(RowContainer)modelData.get(1);
               for (int i=1; i<size-1; i++) {
                   bottomRow.setRowData(i,firstRow.getRowData(i));
               }
               for (int i=2; i<rowCount-1; i++) {
                   RowContainer row=(RowContainer)modelData.get(i);
                   for (int j=1; j<size-1; j++) {
                       Number currentSum=(Number)bottomRow.getRowData(j);
                       Number currentValue=(Number)row.getRowData(j);
                       if (currentSum!=null) {
                           if (currentValue!=null) {
                               double sum=currentValue.doubleValue()+currentSum.doubleValue();
                               bottomRow.setRowData(j,new Double(sum));
                           }
                       }
                       else {
                           bottomRow.setRowData(j,currentValue);
                       }
                   }
               }
           }
       }
       else {
           //vertical
           if (size>=3) {
               for (int i=1; i<rowCount-1; i++) {
                   RowContainer row=(RowContainer)modelData.get(i);
                   for (int j=1; j<size-1; j++) {
                       Number currentSum=(Number)row.getRowData(size-1);
                       Number currentValue=(Number)row.getRowData(j);
                       if (currentSum!=null) {
                           if (currentValue!=null) {
                               double sum=currentValue.doubleValue()+currentSum.doubleValue();
                               row.setRowData(size-1,new Double(sum));
                           }
                       }
                       else {
                           row.setRowData(size-1,currentValue);
                       }
                   }
               }
           }
       }
   }

   /**
    * Sets AVG cross function.
    * @param direction HORIZONTAL or VERTICAL
    */
   protected void setCrossTabFunctionAVG(int direction) {
       setCrossTabFunctionSUM(direction);
       int rowCount=getRowCount();
       RowContainer bottomRow=(RowContainer)modelData.get(getRowCount()-1);
       int size=bottomRow.getCellCount();
       if (direction==DIRECTION_HORIZONTAL) {
           //horizontal
           for (int i=1; i<size-1; i++) {
               Number sum=(Number)bottomRow.getRowData(i);
               if (sum!=null)
                   bottomRow.setRowData(i,new Double(sum.doubleValue()/(rowCount-2)));
           }
       }
       else {
           //vertical
           for (int i=1; i<rowCount-1; i++) {
               RowContainer row=(RowContainer)modelData.get(i);
               Number sum=(Number)row.getRowData(size-1);
               if (sum!=null)
                   row.setRowData(size-1,new Double(sum.doubleValue()/(size-2)));
           }
       }
   }

   /**
    * Gets current vertical cross function.
    * @return
    */
   public int getVerticalCrossTabFunction() {
       return verticalCrossTabFunction;
   }

   /**
    * Gets current horizontal cross function.
    * @return
    */
   public int getHorizontalCrossTabFunction() {
       return horizontalCrossTabFunction;
   }

}

