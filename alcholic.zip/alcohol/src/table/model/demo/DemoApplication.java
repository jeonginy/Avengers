package table.model.demo;

import java.sql.Date;
import java.text.*;
import java.util.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import table.model.*;
import table.model.exception.*;
import table.model.renderer.*;

public class DemoApplication {

    JFrame frame;
    JTable demoTable;
    JTable originalTable;

    JScrollPane demoTableScroll;

    EnvelopeTableModel model;
    TableModel originalModel;

    JButton sortButton=new JButton("Set sort");
    JButton groupButton=new JButton("Set group");
    JButton crossTabButton=new JButton("Set cross tab");
    ColumnSelectorControl sortColumns=new ColumnSelectorControl("Sorting: ");
    ColumnSelectorControl groupColumns=new ColumnSelectorControl("Grouping: ");
    GroupFunctionControl groupFunctions=new GroupFunctionControl("Group functions: ");

    CrossTabControl crossColumns=new CrossTabControl("Cross tab: ");

    JButton deleteOriginalRow=new JButton("Delete");
    JButton insertOriginalRow=new JButton("Insert");

    JTabbedPane rightTab=new JTabbedPane();

    public DemoApplication() {
        JFrame frame=new JFrame("Demo of EnvelopeTableModel functionality.");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        originalModel=DemoModel.getDemoModel();
        model=new EnvelopeTableModel(originalModel);
        demoTable=new JTable(model);
        demoTable.getColumnModel().getColumn(0).setPreferredWidth(90);
        demoTable.getColumnModel().getColumn(2).setPreferredWidth(105);
        demoTable.getColumnModel().getColumn(4).setPreferredWidth(100);

        demoTable.setDefaultRenderer(String.class,new SimpleRenderer(true));
        demoTable.setDefaultRenderer(Date.class,new SimpleRenderer(true));
        demoTable.setDefaultRenderer(Object.class,new SimpleRenderer(true));

        demoTable.setDefaultRenderer(Double.class,new NumberRenderer(true));
        demoTable.setDefaultRenderer(Float.class,new NumberRenderer(true));
        demoTable.setDefaultRenderer(Integer.class,new NumberRenderer(true));
        demoTable.setDefaultRenderer(Long.class,new NumberRenderer(true));
/*        try {
            model.setGroup(new int[] {0,1},new boolean[] {true,true});

            model.setGroupFunction(4,EnvelopeTableModel.GROUP_FUNCTION_SUM);
            model.setGroupFunction(2,EnvelopeTableModel.GROUP_FUNCTION_MAX);
            model.setGroupFunction(3,EnvelopeTableModel.GROUP_FUNCTION_SUM);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }*/
        showDefaultCross();

        JPanel originalPanel=new JPanel();
        createLeftPanel(originalPanel);

        JPanel rightPanel=new JPanel();
        createRightPanel(rightPanel);

        demoTableScroll=new JScrollPane(demoTable);

        JTabbedPane tabbedPane=new JTabbedPane();
        tabbedPane.add("Envelope model",demoTableScroll);
        tabbedPane.add("Source data model",originalPanel);

        JSplitPane split=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,tabbedPane,rightPanel);
        frame.getContentPane().add(split);

        GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Rectangle bounds = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
        bounds.height-=50;

//        frame.setSize(790,590);
        frame.setBounds(bounds);
        split.setDividerLocation(bounds.width-350);
        split.setDividerSize(3);

        initListeners();
        frame.show();
    }

    private void createLeftPanel(JPanel leftPanel) {
        originalTable=new JTable(originalModel);
        leftPanel.setLayout(new GridBagLayout());
        leftPanel.add(new JScrollPane(originalTable),new GridBagConstraints(0,0,3,1,1,1,GridBagConstraints.NORTHWEST,GridBagConstraints.BOTH,new Insets(0,0,0,0),0,0));
        leftPanel.add(new JLabel(" "),new GridBagConstraints(0,1,1,1,1,0,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
        leftPanel.add(insertOriginalRow,new GridBagConstraints(1,1,1,1,0,0,GridBagConstraints.NORTHEAST,GridBagConstraints.NONE,new Insets(5,0,5,5),0,0));
        leftPanel.add(deleteOriginalRow,new GridBagConstraints(2,1,1,1,0,0,GridBagConstraints.NORTHEAST,GridBagConstraints.NONE,new Insets(5,0,5,0),0,0));
        originalTable.getColumnModel().getColumn(2).setCellEditor(new DateCellEditor());
    }

    private void createRightPanel(JPanel rightPanel) {
        rightPanel.setLayout(new BorderLayout());
        rightPanel.add(rightTab);

        //sort properties
        JPanel sortPanel=new JPanel(new GridBagLayout());
        rightTab.addTab("Sort ",sortPanel);
        sortColumns.setColumns(originalTable);
        sortPanel.add(sortColumns,new GridBagConstraints(0,0,2,1,1,0,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(5,5,5,5),0,0));
        sortPanel.add(sortButton,new GridBagConstraints(1,1,1,1,0,0,GridBagConstraints.NORTHEAST,GridBagConstraints.NONE,new Insets(0,0,5,5),0,0));
        sortPanel.add(new JLabel(),new GridBagConstraints(0,3,1,1,0,1,GridBagConstraints.NORTHWEST,GridBagConstraints.VERTICAL,new Insets(0,0,0,0),0,0));
        JButton b=new JButton("Show default sort abilities");
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showDefaultSort();
            }
        });
        sortPanel.add(b,new GridBagConstraints(0,4,2,1,1,0,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));

        //group properties
        JPanel groupPanel=new JPanel(new GridBagLayout());
        rightTab.addTab("Group ",groupPanel);
        groupColumns.setColumns(originalTable);

        //--init--
        DefaultTableModel modelAll=(DefaultTableModel)groupColumns.allColumns.getModel();
        DefaultTableModel modelSelected=(DefaultTableModel)groupColumns.selectedColumns.getModel();
        Object colName=modelAll.getValueAt(0,0);
        modelSelected.addRow(new Object[] {colName,new Boolean(true)});
        colName=modelAll.getValueAt(1,0);
        modelSelected.addRow(new Object[] {colName,new Boolean(true)});
        modelAll.removeRow(0);
        modelAll.removeRow(0);
        //--init--

        groupPanel.add(groupColumns,new GridBagConstraints(0,0,2,1,1,0,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(0,5,5,5),0,0));

        groupFunctions.setColumns(originalTable);
        DefaultTableModel model=(DefaultTableModel)groupFunctions.allColumns.getModel();
        model.setValueAt("MAX",2,1);
        model.setValueAt("SUM",3,1);
        model.setValueAt("SUM",4,1);

        groupPanel.add(groupFunctions,new GridBagConstraints(0,1,2,1,1,0,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(0,5,0,5),0,100));
        groupPanel.add(groupButton,new GridBagConstraints(1,2,1,1,0,0,GridBagConstraints.NORTHEAST,GridBagConstraints.NONE,new Insets(0,0,5,5),0,0));

        groupPanel.add(new JLabel(),new GridBagConstraints(0,3,1,1,0,1,GridBagConstraints.NORTHWEST,GridBagConstraints.VERTICAL,new Insets(0,0,0,0),0,0));
        b=new JButton("Show default group abilities");
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showDefaultGroup();
            }
        });
        groupPanel.add(b,new GridBagConstraints(0,4,2,1,1,0,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));

        //crosstab properties
        JPanel crossPanel=new JPanel(new GridBagLayout());
        rightTab.addTab("CrossTab ",crossPanel);
        crossColumns.setTableModel(originalModel);
        crossColumns.setAll(2,1,4);
        crossColumns.setFunctions(4,5);
        crossPanel.add(crossColumns,new GridBagConstraints(0,0,2,1,1,0,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(5,5,5,5),0,0));
        crossPanel.add(crossTabButton,new GridBagConstraints(1,1,1,1,0,0,GridBagConstraints.NORTHEAST,GridBagConstraints.NONE,new Insets(0,0,5,5),0,0));
        crossPanel.add(new JLabel(),new GridBagConstraints(0,3,1,1,0,1,GridBagConstraints.NORTHWEST,GridBagConstraints.VERTICAL,new Insets(0,0,0,0),0,0));
        b=new JButton("Show default cross tab abilities");
        b.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showDefaultCross();
            }
        });
        crossPanel.add(b,new GridBagConstraints(0,4,2,1,1,0,GridBagConstraints.NORTHWEST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));

        rightTab.setSelectedIndex(2);
    }

    protected void restoreNormalColumnModel() {
        demoTable.setColumnModel(new DefaultTableColumnModel());
        demoTable.setTableHeader(new JTableHeader(demoTable.getColumnModel()));
        demoTable.tableChanged(new TableModelEvent(model, TableModelEvent.HEADER_ROW));
        demoTable.setDefaultRenderer(Object.class,new SimpleRenderer(true));
        demoTableScroll.setColumnHeaderView(demoTable.getTableHeader());
    }

    protected void initListeners() {
        sortButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int count=sortColumns.getSelectedColumnCount();
                if (count==0) return;
                if (JOptionPane.showConfirmDialog(null,"It'll change existing sort and group orders. Continue?","Warning",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)
                    return;

                int[] sortColumnIndexes=new int[count];
                boolean[] sortOrders=new boolean[count];
                for (int i=0; i<count; i++) {
                    int index=demoTable.getColumnModel().getColumnIndex(sortColumns.getSelectedColumnName(i));
                    index=demoTable.convertColumnIndexToModel(index);
                    sortColumnIndexes[i]=index;
                    sortOrders[i]=sortColumns.getSelectedColumnOrder(i);
                }
                try {
                    model.setSort(sortColumnIndexes,sortOrders);
                    restoreNormalColumnModel();
                }
                catch (SortException ex) {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
            }
        });
        groupButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int count=groupColumns.getSelectedColumnCount();
                if (count==0) return;
                if (JOptionPane.showConfirmDialog(null,"It'll change existing sort and group orders. Continue?","Warning",JOptionPane.OK_CANCEL_OPTION)!=JOptionPane.OK_OPTION)
                    return;
                int[] groupColumnIndexes=new int[count];
                boolean[] groupOrders=new boolean[count];
                for (int i=0; i<count; i++) {
                    int index=demoTable.getColumnModel().getColumnIndex(groupColumns.getSelectedColumnName(i));
                    index=demoTable.convertColumnIndexToModel(index);
                    groupColumnIndexes[i]=index;
                    groupOrders[i]=groupColumns.getSelectedColumnOrder(i);
                }
                try {
                    model.setGroup(groupColumnIndexes,groupOrders);
                    count=model.getColumnCount();
                    for (int i=0; i<count; i++) {
                        int function=groupFunctions.getFunction(i);
                        if (function!=EnvelopeTableModel.GROUP_FUNCTION_EMPTY)
                            model.setGroupFunction(i,function);
                    }

                    restoreNormalColumnModel();
                }
                catch (GroupException ex) {
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
            }
        });

        crossTabButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int verticalColumn=crossColumns.verticalColumnCombo.getSelectedIndex();
                int horizontalColumn=crossColumns.horizontalColumnCombo.getSelectedIndex();
                int crossColumn=crossColumns.crossColumnCombo.getSelectedIndex();

                int verticalFunction=crossColumns.verticalFunctionCombo.getSelectedIndex();
                int horizontalFunction=crossColumns.horizontalFunctionCombo.getSelectedIndex();
                try {
                    model.reset();
                    demoTable.setDefaultRenderer(Object.class,new CrossTabRenderer());
                    model.setCrossTab(verticalColumn,true,horizontalColumn,true,crossColumn);

                    model.setCrossTabFunction(horizontalFunction,EnvelopeTableModel.DIRECTION_HORIZONTAL);
                    model.setCrossTabFunction(verticalFunction,EnvelopeTableModel.DIRECTION_VERTICAL);
                    demoTable.setTableHeader(null);
                    demoTable.tableChanged(new TableModelEvent(model,TableModelEvent.HEADER_ROW));
                    if (demoTableScroll!=null)
                    demoTableScroll.setColumnHeader(null);
                }
                catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        });

        deleteOriginalRow.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int rowIndex=originalTable.getSelectedRow();
                if (rowIndex>-1) {
                    ((DefaultTableModel)originalModel).removeRow(rowIndex);
                }
            }
        });
        insertOriginalRow.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DefaultTableModel model=(DefaultTableModel)originalModel;
                int rowCount=model.getRowCount();
                int columnCount=model.getColumnCount();
                model.insertRow(rowCount,new Object[columnCount]);
            }
        });
    }

    public void showDefaultSort() {
        try {
            model.reset();
            model.setSort(new int[] {0,1},new boolean[] {true,true});

            demoTable.setTableHeader(new JTableHeader(demoTable.getColumnModel()));
            demoTableScroll.setColumnHeaderView(demoTable.getTableHeader());
            demoTable.tableChanged(new TableModelEvent(model));
            demoTable.tableChanged(new TableModelEvent(model,TableModelEvent.HEADER_ROW));

            sortColumns.setColumns(originalTable);
            sortColumns.setSelectedColumns(new int[] {0,1});
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void showDefaultGroup() {
        try {
            model.reset();
            model.setGroup(new int[] {0,1},new boolean[] {true,true});

            model.setGroupFunction(4,EnvelopeTableModel.GROUP_FUNCTION_SUM);
            model.setGroupFunction(2,EnvelopeTableModel.GROUP_FUNCTION_MAX);
            model.setGroupFunction(3,EnvelopeTableModel.GROUP_FUNCTION_SUM);

            demoTable.setTableHeader(new JTableHeader(demoTable.getColumnModel()));
            demoTableScroll.setColumnHeaderView(demoTable.getTableHeader());
            demoTable.tableChanged(new TableModelEvent(model));
            demoTable.tableChanged(new TableModelEvent(model,TableModelEvent.HEADER_ROW));

            groupColumns.setColumns(originalTable);
            groupColumns.setSelectedColumns(new int[] {0,1});
            groupFunctions.setFunction(0,"EMPTY");
            groupFunctions.setFunction(1,"EMPTY");
            groupFunctions.setFunction(2,"MAX");
            groupFunctions.setFunction(3,"SUM");
            groupFunctions.setFunction(4,"SUM");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void showDefaultCross() {
        try {
            model.reset();
            demoTable.setDefaultRenderer(Object.class,new CrossTabRenderer());
            model.setCrossTab(1,true,2,true,4);

            model.setCrossTabFunction(EnvelopeTableModel.GROUP_FUNCTION_SUM,EnvelopeTableModel.DIRECTION_HORIZONTAL);
            model.setCrossTabFunction(EnvelopeTableModel.GROUP_FUNCTION_AVG,EnvelopeTableModel.DIRECTION_VERTICAL);
            demoTable.setTableHeader(null);
            demoTable.tableChanged(new TableModelEvent(model,TableModelEvent.HEADER_ROW));
            if (demoTableScroll!=null)
                demoTableScroll.setColumnHeader(null);

            crossColumns.setAll(2, 1, 4);
            crossColumns.setFunctions(4, 5);
    }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] agrs) throws Exception{
        new DemoApplication();
    }

//--- INNER CLASSES ------------------------------------------------------------
    class DateCellEditor extends JTextField implements TableCellEditor {
        int rowNumber=-1;
        ArrayList listenerList=new ArrayList();
        Object value;

        public Component getTableCellEditorComponent(JTable table, Object value,
                                      boolean isSelected,
                                      int row, int column) {
            rowNumber=row;
            SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
            this.value=value;
            if (value==null) {
                setText(format.format(new Date(System.currentTimeMillis() )));
            }
            else {
                setText(format.format((Date)value));
            }
            return this;
        }

        public Object getCellEditorValue() {
            return value;
        }
        public boolean isCellEditable(EventObject anEvent) {
            return true;
        }
        public boolean shouldSelectCell(EventObject anEvent) {
            return true;
        }
        public boolean stopCellEditing() {
            try {
                String text=getText();

                value=Date.valueOf(text);
                fireEditingStopped();
                return true;
            }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(null,"Incorrect value! Should be 'yyyy-mm-dd'");
                this.requestFocus();
                return false;
            }
        }
        public void cancelCellEditing() {
        }
        public void addCellEditorListener(CellEditorListener l) {
            listenerList.add(l);
        }
        public void removeCellEditorListener(CellEditorListener l) {
            listenerList.remove(l);
        }
        public void fireEditingStopped() {
            ChangeEvent changeEvent = new ChangeEvent(this);
            for (int i=0; i<listenerList.size(); i++) {
                ((CellEditorListener)listenerList.get(i)).editingStopped(changeEvent);
            }
        }
    }
}