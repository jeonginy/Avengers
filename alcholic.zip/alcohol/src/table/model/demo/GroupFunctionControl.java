package table.model.demo;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.event.*;
import table.model.EnvelopeTableModel;

public class GroupFunctionControl extends JPanel implements TableCellEditor {

    JTable allColumns=new JTable();
    JComboBox functionCombo=new JComboBox();
    DefaultComboBoxModel defaultFunctions=new DefaultComboBoxModel(new String[] {"EMPTY","COUNT"});
    DefaultComboBoxModel comparableFunctions=new DefaultComboBoxModel(new String[] {"EMPTY","COUNT","MIN","MAX"});
    DefaultComboBoxModel numberFunctions=new DefaultComboBoxModel(new String[] {"EMPTY","COUNT","MIN","MAX","SUM","AVG"});

    ArrayList listenerList=new ArrayList();

    public GroupFunctionControl() {
        this("");
    }
    public GroupFunctionControl(String title) {
        super();
        setBorder(new TitledBorder(new EtchedBorder(),title));
        setLayout(new GridBagLayout());
        JScrollPane scroll=new JScrollPane(allColumns);
        add(scroll,new GridBagConstraints(0,0,1,1,1,1,GridBagConstraints.NORTHWEST,GridBagConstraints.BOTH,new Insets(0,0,0,5),0,0));
        initListeners();
    }

    protected void initListeners() {
        functionCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                stopCellEditing();
            }
        });
    }

    public void setColumns(JTable table) {
        TableColumnModel columnModel=table.getColumnModel();
        int cnt=columnModel.getColumnCount();
        Object[][] sourceData=new Object[cnt][3] ;
        for (int i=0; i<cnt; i++) {
            sourceData[i][0]=table.getColumnName(i);
            sourceData[i][1]="EMPTY";
            sourceData[i][2]=table.getModel().getColumnClass(i);
        }

        allColumns.setModel(new SelectionModel(sourceData,new String[] {"Column name","Function",""}));

        allColumns.getColumnModel().getColumn(1).setCellEditor(this);
        TableColumn tc=allColumns.getColumnModel().getColumn(2);
        allColumns.getColumnModel().removeColumn(tc);
    }

    public void setFunction(int columnIndex,String function) {
        ((DefaultTableModel)allColumns.getModel()).setValueAt(function,columnIndex,1);
    }

    public int getFunction(int columnIndex) {
        String s=(String)allColumns.getModel().getValueAt(columnIndex,1);
        if ("COUNT".equals(s)) {
            return EnvelopeTableModel.GROUP_FUNCTION_COUNT;
        }
        else if ("MIN".equals(s)) {
            return EnvelopeTableModel.GROUP_FUNCTION_MIN;
        }
        else if ("MAX".equals(s)) {
            return EnvelopeTableModel.GROUP_FUNCTION_MAX;
        }
        else if ("SUM".equals(s)) {
            return EnvelopeTableModel.GROUP_FUNCTION_SUM;
        }
        else if ("AVG".equals(s)) {
            return EnvelopeTableModel.GROUP_FUNCTION_AVG;
        }
        return EnvelopeTableModel.GROUP_FUNCTION_EMPTY;
    }

//--- TableCellEditor methods --------------------------------------------------
    public Component getTableCellEditorComponent(JTable table, Object value,
                                          boolean isSelected,
                                          int row, int column) {
        Class columnClass=(Class)table.getModel().getValueAt(row,2);
        if (Number.class.isAssignableFrom(columnClass)) {
            functionCombo.setModel(numberFunctions);
        }
        else if (Comparable.class.isAssignableFrom(columnClass)) {
            functionCombo.setModel(comparableFunctions);
        }
        else
            functionCombo.setModel(defaultFunctions);
        return functionCombo;
    }
    public Object getCellEditorValue() {
        return functionCombo.getSelectedItem();
    }

    public boolean isCellEditable(EventObject anEvent) {
        return true;
    }

    public boolean shouldSelectCell(EventObject anEvent) {
        return true;
    }

    public boolean stopCellEditing() {
        int size=listenerList.size();
        for (int i=0; i<size; i++) {
            ((CellEditorListener)listenerList.get(i)).editingStopped(new ChangeEvent(this));
        }
        return true;
    }

    public void cancelCellEditing() {
        int size=listenerList.size();
        for (int i=0; i<size; i++) {
            ((CellEditorListener)listenerList.get(i)).editingCanceled(new ChangeEvent(this));
        }
    }

    public void addCellEditorListener(CellEditorListener l) {
        listenerList.add(l);
    }
    public void removeCellEditorListener(CellEditorListener l){
        listenerList.remove(l);
    }

    class SelectionModel extends DefaultTableModel {
        public SelectionModel(Object[][] data, Object[] columnNames) {
            super(data,columnNames);
        }

        public SelectionModel(Object[] columnNames, int rowCount) {
            super(columnNames,rowCount);
        }

        public boolean isCellEditable(int row, int column) {
            return (column!=0);
        }

    }
}