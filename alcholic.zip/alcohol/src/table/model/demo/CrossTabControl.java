package table.model.demo;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.event.*;

public class CrossTabControl extends JPanel {

    protected JComboBox horizontalColumnCombo=new JComboBox();
    protected JComboBox verticalColumnCombo=new JComboBox();
    protected JComboBox crossColumnCombo=new JComboBox();

    protected JComboBox horizontalFunctionCombo=new JComboBox();
    protected JComboBox verticalFunctionCombo=new JComboBox();

    TableModel sourceModel;

    String[] defaultFunctions=new String[] {"EMPTY","COUNT"};
    String[] comparableFunctions=new String[] {"EMPTY","COUNT","MAX","MIN"};
    String[] numberFunctions=new String[] {"EMPTY","COUNT","MAX","MIN","SUM","AVG"};

    public CrossTabControl(String title) {
        super(new GridBagLayout());
        setBorder(new TitledBorder(new EtchedBorder(),title));
        init();
    }

    protected void init() {
        this.add(new JLabel("Horizontal column: "),new GridBagConstraints(0,0,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        this.add(horizontalColumnCombo,new GridBagConstraints(1,0,1,1,1,0,GridBagConstraints.EAST,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));

        this.add(new JLabel("Vertical column: "),new GridBagConstraints(0,1,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        this.add(verticalColumnCombo,new GridBagConstraints(1,1,1,1,0,0,GridBagConstraints.NORTH,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));

        this.add(new JLabel("Cross column: "),new GridBagConstraints(0,2,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        this.add(crossColumnCombo,new GridBagConstraints(1,2,1,1,0,0,GridBagConstraints.NORTH,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));

        this.add(new JLabel("Horizontal function: "),new GridBagConstraints(0,4,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(20,0,0,0),0,0));
        this.add(horizontalFunctionCombo,new GridBagConstraints(1,4,1,1,0,0,GridBagConstraints.NORTH,GridBagConstraints.HORIZONTAL,new Insets(20,0,0,0),0,0));
        horizontalFunctionCombo.setModel(new DefaultComboBoxModel(defaultFunctions));

        this.add(new JLabel("Vertical function: "),new GridBagConstraints(0,5,1,1,0,0,GridBagConstraints.WEST,GridBagConstraints.NONE,new Insets(0,0,0,0),0,0));
        this.add(verticalFunctionCombo,new GridBagConstraints(1,5,1,1,0,0,GridBagConstraints.NORTH,GridBagConstraints.HORIZONTAL,new Insets(0,0,0,0),0,0));
        verticalFunctionCombo.setModel(new DefaultComboBoxModel(defaultFunctions));

        initListeners();
    }

    protected void initListeners() {
        crossColumnCombo.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int columnIndex=crossColumnCombo.getSelectedIndex();
                Class columnClass=sourceModel.getColumnClass(columnIndex);
                if (Number.class.isAssignableFrom(columnClass)) {
                    horizontalFunctionCombo.setModel(new DefaultComboBoxModel(numberFunctions));
                    verticalFunctionCombo.setModel(new DefaultComboBoxModel(numberFunctions));
                }
                else if (Comparable.class.isAssignableFrom(columnClass)) {
                    horizontalFunctionCombo.setModel(new DefaultComboBoxModel(comparableFunctions));
                    verticalFunctionCombo.setModel(new DefaultComboBoxModel(comparableFunctions));
                }
                else {
                    horizontalFunctionCombo.setModel(new DefaultComboBoxModel(defaultFunctions));
                    verticalFunctionCombo.setModel(new DefaultComboBoxModel(defaultFunctions));
                }
            }
        });
    }

    public void setTableModel(TableModel sourceModel) {
        this.sourceModel=sourceModel;
        if (sourceModel!=null) {

            int colCount=sourceModel.getColumnCount();
            String[] items=new String[colCount];
            for (int i=0; i<colCount; i++) {
                items[i]=sourceModel.getColumnName(i);
            }
            horizontalColumnCombo.setModel(new DefaultComboBoxModel(items));
            verticalColumnCombo.setModel(new DefaultComboBoxModel(items));
            crossColumnCombo.setModel(new DefaultComboBoxModel(items));
        }
    }

    public void setAll(int hCol, int vCol, int cCol) {
        if (sourceModel==null)
            return;

        String vColName=sourceModel.getColumnName(vCol);
        String hColName=sourceModel.getColumnName(hCol);
        String cColName=sourceModel.getColumnName(cCol);

        horizontalColumnCombo.setSelectedIndex(hCol);
        verticalColumnCombo.setSelectedIndex(vCol);
        crossColumnCombo.setSelectedIndex(cCol);
    }

    public void setFunctions(int hFunc, int vFunc) {
        if (sourceModel==null)
            return;
        horizontalFunctionCombo.setSelectedIndex(hFunc);
        verticalFunctionCombo.setSelectedIndex(vFunc);
    }
}
