package table.model.demo;

import javax.swing.table.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.sql.Date;

public class DemoModel extends DefaultTableModel {

    public DemoModel(Object[][] data, Object[] columnNames) {
        super(data,columnNames);
    }

    public Class getColumnClass(int columnIndex) {
        if (columnIndex==1 || columnIndex==0)
            return String.class;
        else if (columnIndex==2)
            return Date.class;
        else if (columnIndex==3)
            return Long.class;
        else if (columnIndex==4)
            return Float.class;
        else
            return Object.class;
    }

    public static TableModel getDemoModel() {
        Object[][] ss=new Object[][] {
            {"Customer1","Good1",new Date(103,1,9),new Long(7),new Float(704.9)}
            ,{"Customer1","Good1",new Date(103,1,15),new Long(7),new Float(704.9)}
            ,{"Customer2","Good5",new Date(103,1,15),new Long(20),new Float(19)}
            ,{"Customer1","Good2",new Date(103,1,9),new Long(5),new Float(249.5)}
            ,{"Customer1","Good2",new Date(103,1,15),new Long(1),new Float(49.9)}
            ,{"Customer1","Good3",new Date(103,1,17),new Long(2),new Float(11.2)}
            ,{"Customer1","Good3",new Date(103,1,19),new Long(1),new Float(5.6)}
            ,{"Customer2","Good2",new Date(103,1,9),new Long(5),new Float(249.5)}
            ,{"Customer2","Good2",new Date(103,1,15),new Long(5),new Float(249.5)}
            ,{"Customer2","Good2",new Date(103,1,17),new Long(5),new Float(249.5)}
            ,{"Customer1","Good4",new Date(103,1,9),new Long(1),new Float(3.39)}
            ,{"Customer1","Good4",new Date(103,1,19),new Long(3),new Float(10.17)}
            ,{"Customer1","Good4",new Date(103,1,15),new Long(1),new Float(3.39)}
            ,{"Customer1","Good4",new Date(103,1,17),new Long(3),new Float(10.17)}
            ,{"Customer2","Good5",new Date(103,1,9),new Long(10),new Float(9.5)}
            ,{"Customer2","Good5",new Date(103,1,19),new Long(36),new Float(34.2)}
            ,{"Customer1","Good2",new Date(103,1,17),new Long(4),new Float(199.6)}
            ,{"Customer2","Good2",new Date(103,1,19),new Long(5),new Float(249.5)}
            ,{"Customer2","Good1",new Date(103,1,12),new Long(15),new Float(1510.5)}
        };
/*        int rowCount=10000;
        ss=new String[rowCount][3];
        for (int i=0; i<rowCount; i++) {
            ss[i][0]=Integer.toString(i);
        }*/
        DemoModel dm=new DemoModel(ss,new String[] {"Customers","Goods","Date","Quantity","Sum"});
        return dm;
    }
}