package table.model.exception;

/**
 * Represents exceptions for grouping actions.
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class SortException extends EnvelopeModelException {

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param   message   the detail message.
     */
    public SortException(String message) {
        super(message);
    }
}