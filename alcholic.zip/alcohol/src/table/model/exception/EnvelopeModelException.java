package table.model.exception;

/**
 * The base class for all EnvelopeModel's exceptions.
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class EnvelopeModelException extends Exception {

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param   message   the detail message.
     */
    public EnvelopeModelException(String message) {
        super(message);
    }
}