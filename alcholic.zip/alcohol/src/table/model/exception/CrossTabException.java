package table.model.exception;

/**
 * Represents exceptions for cross-tab actions.
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class CrossTabException extends EnvelopeModelException {

    /**
     * Constructs a new exception with the specified detail message.
     *
     * @param   message   the detail message.
     */
    public CrossTabException(String message) {
        super(message);
    }
}