package table.model;

import javax.swing.table.*;
import java.util.*;

/**
 * Creates corss-tab data.
 *
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class CrossTabCreator {

    /**
     * Original TableModel.
     */
    protected TableModel sourceModel;

    /**
     * Column index of original model which represent vertical cross column
     */
    protected int verticalColumnIndex;
    /**
     * Sort order of vertical column.
     */
    protected boolean verticalColumnOrder;

    /**
     * Column index of original model which represent horizontal cross column
     */
    protected int horizontalColumnIndex;
    /**
     * Sort order of horizontal column.
     */
    protected boolean horizontalColumnOrder;

    /**
     * Column index of original model which represent cross column
     */
    protected int crossColumnIndex;

    /**
     * Contains result of cross creation (rows).
     */
    protected ArrayList crossResults;

    /**
     * Constructs new instance.
     */
    public CrossTabCreator() {
        this(null);
    }

    /**
     * Constructs new instance with predefined original model.
     *
     * @param sourceModel original model.
     */
    public CrossTabCreator(TableModel sourceModel) {
        this.sourceModel=sourceModel;
    }

    /**
     * Specifies cross tab definition.
     *
     * @param verticalColumnNumber
     * @param verticalSortOrder
     * @param horizontalColumnNumber
     * @param horizontalSortOrder
     * @param crossColumnNumber
     */
    public void setCrossTab(int verticalColumnNumber,boolean verticalSortOrder,int horizontalColumnNumber,boolean horizontalSortOrder,int crossColumnNumber) {
        this.verticalColumnIndex=verticalColumnNumber;
        this.verticalColumnOrder=verticalSortOrder;
        this.horizontalColumnIndex=horizontalColumnNumber;
        this.horizontalColumnOrder=horizontalSortOrder;
        this.crossColumnIndex=crossColumnNumber;
    }

    /**
     * Regroups original data to represent cross results.
     * @return list of cross rows.
     */
    public ArrayList createCrossTab() {
        crossResults=new ArrayList();
        int rowCount=sourceModel.getRowCount();
        RowContainer titleRow=new RowContainer(-1,false,1);
        titleRow.setRowData(0,null);
        crossResults.add(titleRow);
        for (int i=0; i<rowCount; i++) {
            Object verticalValue=sourceModel.getValueAt(i,verticalColumnIndex);
            Object horizontalValue=sourceModel.getValueAt(i,horizontalColumnIndex);
            Object crossValue=sourceModel.getValueAt(i,crossColumnIndex);
            int rowIndex=getRowByValue(verticalValue);
            int columnIndex=getColumnByValue(horizontalValue);
            int cellCount=titleRow.getCellCount();

            if (columnIndex<0) {
                titleRow.setRowData(cellCount,horizontalValue);
                int size=crossResults.size();
                for (int j=1; j<size; j++) {
                    RowContainer r=(RowContainer)crossResults.get(j);
                    r.setRowData(cellCount,null);
                }
                columnIndex=cellCount;
            }

            RowContainer row;
            if (rowIndex<0) {
                RowContainer newRow=new RowContainer(-1,false,1);
                newRow.setRowData(0,verticalValue);
                for (int j=1; j<cellCount; j++) {
                    newRow.setRowData(j,null);
                }
                crossResults.add(newRow);
                row=newRow;
            }
            else {
                row=(RowContainer)crossResults.get(rowIndex);
            }

            row.setRowData(columnIndex,crossValue);
        }

        int size=crossResults.size();
        int cellCount=titleRow.getCellCount();
        for (int i=0; i<size; i++) {
            RowContainer r=(RowContainer)crossResults.get(i);
            r.setRowData(cellCount,null);
        }
        RowContainer newRow=new RowContainer(-1,false,1);
        for (int i=0; i<=cellCount; i++) {
            newRow.setRowData(i,null);
        }
        crossResults.add(newRow);
        return crossResults;
    }

    /**
     * Gets row index which contains specified value.
     * @param value
     * @return
     */
    protected int getRowByValue(Object value) {
        int rowCount=crossResults.size();
        for (int i=1; i<rowCount; i++) {
            RowContainer row=(RowContainer)crossResults.get(i);
            if (row.getRowData(0).equals(value)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Gets column index which contains specified value.
     * @param value
     * @return
     */
    protected int getColumnByValue(Object value) {
        RowContainer row=(RowContainer)crossResults.get(0);
        int colCount=row.getCellCount();
        for (int i=1; i<colCount; i++) {
            if (row.getRowData(i).equals(value)) {
                return i;
            }
        }
        return -1;
    }
}