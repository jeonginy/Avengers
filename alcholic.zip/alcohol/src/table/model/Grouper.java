package table.model;

import javax.swing.table.*;
import java.util.*;
import table.model.exception.GroupException;

/**
 * Perform table's data grouping.
 *
 * @author Stanislav Lapitsky
 * @version 1.0
 */
public class Grouper {

    /**
     * Original TableModel.
     */
    protected TableModel sourceModel;

    /**
     * Group columns.
     */
    protected int[] groupColumnIndexes;

    /**
     * Sort orders for each column from groupColumnIndexes.
     */
    protected boolean[] groupOrders;

    /**
     * Grouped rows data.
     */
    protected ArrayList groupResults;

    /**
     * An auxiliary array for saving sortings.
     */
    protected int[] sortResults;

    /**
     * Performs preliminary data sorting.
     */
    protected Sorter sorter;

    /**
     * It's used as container for group children.
     */
    protected ArrayList[] groupChildren;

    /**
     * Creates new instance.
     */
    public Grouper() {
        this(null,new int[] {});
    }

    /**
     * Constructs grouper with specified TableModel.
     *
     * @param source original TableModel.
     */
    public Grouper(TableModel source) {
        this(source,new int[] {});
    }

    /**
     * Constructs grouper with specified TableModel and group indexes.
     *
     * @param source original TableModel.
     * @param groupColumnIndexes group indexes.
     */
    public Grouper(TableModel source, int[] groupColumnIndexes) {
        this.sourceModel=source;
        this.groupColumnIndexes=groupColumnIndexes;
        groupChildren=new ArrayList[groupColumnIndexes.length+2];
    }

    /**
     * Sets original TableModel.
     *
     * @param source original TableModel.
     */
    public void setSourceTableModel(TableModel source) {
        this.sourceModel=source;
    }

    /**
     * Sets grouping functions.
     *
     * @param groupColumnIndexes group columns.
     * @throws Exception
     */
    public void setGroup(int[] groupColumnIndexes) throws Exception {
        setGroup(groupColumnIndexes,new boolean[groupColumnIndexes.length]);
    }

    /**
     * Sets grouping functions.
     *
     * @param groupColumnIndexes group columns.
     * @param groupOrders orders of grouped columns.
     * @throws GroupException
     */
    public void setGroup(int[] groupColumnIndexes,boolean[] groupOrders) throws GroupException {
        if (groupColumnIndexes.length!=groupOrders.length) {
            throw new GroupException("Number of grouping column indexes isn't equal to number of grouping orders!");
        }
        this.groupColumnIndexes=groupColumnIndexes;
        this.groupOrders=groupOrders;
        groupChildren=new ArrayList[groupColumnIndexes.length+2];
    }

//------------------------------------------------------------------------------

   /**
    * Performs grouping.
    *
    * @return list of rows.
    * @throws GroupException
    */
    public ArrayList group() throws GroupException {
        if ((sourceModel==null) || (groupColumnIndexes==null)) {
            return null;
        }
        sorter=new Sorter(sourceModel,groupColumnIndexes,groupOrders);
        sortResults=sorter.sort();

        fillGroup();

        return groupResults;
    }

    /**
     * Creates group list.
     */
    protected void fillGroup() {
        int cnt=sortResults.length;
        groupResults=new ArrayList(cnt);

        int groupCount=groupColumnIndexes.length;
        int previousRowIndex=0;
        int columnCount=sourceModel.getColumnCount();

        RowContainer row=new RowContainer(sortResults[0],true,columnCount);
        groupResults.add(row);
        addRowToGroup(row);
        for (int i=1; i<cnt; i++) {
            int additionalRowCount=groupCount;
            for (int j=0; j<groupCount; j++) {
                int columnIndex=groupColumnIndexes[j];
                int previousOriginalRowIndex=sortResults[previousRowIndex];
                int currentOriginalRowIndex=sortResults[i];

                Object previousObj=sourceModel.getValueAt(previousOriginalRowIndex,columnIndex);
                Object currentObj=sourceModel.getValueAt(currentOriginalRowIndex,columnIndex);
                if (previousObj==null) {
                    if (currentObj==previousObj) {
                        additionalRowCount--;
                    }
                    else {
                        break;
                    }
                }
                else if (!previousObj.equals(currentObj)) {
                    break;
                }
                else {
                    additionalRowCount--;
                }
            }

            int level=1;
            for (int j=0; j<additionalRowCount; j++) {
                row=new RowContainer(-1,false,columnCount,level);
                row.children=getGroupChildren(level-1);
                groupResults.add(row);
                addRowToGroup(row);
                level++;
            }
            row=new RowContainer(sortResults[i],true,columnCount);
            groupResults.add(row);
            addRowToGroup(row);
            previousRowIndex=i;
        }
        int level=1;
        for (int j=0; j<groupCount+1; j++) {
            row=new RowContainer(-1,false,columnCount,level);
            row.children=getGroupChildren(level-1);
            groupResults.add(row);
            addRowToGroup(row);
            level++;
        }
    }

    /**
     * Adds a row to a group.
     * @param row
     */
    protected void addRowToGroup(RowContainer row) {
        int level=row.getLevel();
        if (groupChildren[level]==null) {
            groupChildren[level]=new ArrayList();
        }
        groupChildren[level].add(row);
    }

    /**
     * Gets the children ogf specified group level.
     *
     * @param groupLevel group level
     * @return list of rows.
     */
    protected ArrayList getGroupChildren(int groupLevel) {
        ArrayList result= groupChildren[groupLevel];
        groupChildren[groupLevel]=null;
        return result;
    }
}